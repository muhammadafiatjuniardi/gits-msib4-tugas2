<?php
$hostname = "localhost";
$username = "root";
$password = "";
$database = "bukutamu";

$conn =new mysqli($hostname,$username,$password,$database);

if($conn->connect_error){
    die("failed to connect to mysql :".mysql_connect_error());
}
else{
    echo "Data Berhasil Ditampilkan Ke <a href='home.html'>home</a>";
}
?>