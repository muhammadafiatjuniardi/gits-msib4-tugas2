<?php
include "koneksi.php";

if (isset($_POST['kirim'])) {
    $nama_lengkap = $_POST['nama_lengkap'];
    $alamat = $_POST['alamat'];
    $tempat_lahir = $_POST['tempat_lahir'];
    $tanggal_lahir = $_POST['tanggal_lahir'];
    $jk = $_POST['jk'];
    $info = $_POST['info'];
    $no_telpon = $_POST['no_telpon'];
    $email = $_POST['email'];
    $sosial = $_POST['sosial'];

    $simpan = "INSERT INTO bukutamu(nama_lengkap,alamat,tempat_lahir,tanggal_lahir,jk,info,no_telpon,email,sosial)
    VALUES('$nama_lengkap','$alamat','$tempat_lahir','$tanggal_lahir','$jk','$info','$no_telpon','$email','$sosial')";

    $result = mysqli_query($conn,$simpan);

    if ($result) {
        echo "<script>alert('Data Telah Berhasil Di Simpan');window.location='bukutamu.php'</script>";
    }
}
?>